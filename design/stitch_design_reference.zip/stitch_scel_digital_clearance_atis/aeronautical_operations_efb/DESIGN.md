---
name: Aeronautical Operations / EFB
colors:
  surface: '#001230'
  surface-dim: '#001230'
  surface-bright: '#24395e'
  surface-container-lowest: '#000d27'
  surface-container-low: '#021b3f'
  surface-container: '#061f43'
  surface-container-high: '#13294e'
  surface-container-highest: '#1f3459'
  on-surface: '#d7e2ff'
  on-surface-variant: '#bdc8d1'
  inverse-surface: '#d7e2ff'
  inverse-on-surface: '#1b3055'
  outline: '#88929b'
  outline-variant: '#3e4850'
  surface-tint: '#81cfff'
  primary: '#81cfff'
  on-primary: '#00344b'
  primary-container: '#00a3e0'
  on-primary-container: '#00354b'
  inverse-primary: '#00658d'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#ffb95f'
  on-tertiary: '#472a00'
  tertiary-container: '#d58800'
  on-tertiary-container: '#472a00'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#c6e7ff'
  primary-fixed-dim: '#81cfff'
  on-primary-fixed: '#001e2d'
  on-primary-fixed-variant: '#004c6b'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#001230'
  on-background: '#d7e2ff'
  surface-variant: '#1f3459'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 44px
    letterSpacing: -0.02em
  display-sm:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  telemetry-lg:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0.02em
  telemetry-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.02em
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
  label-regular:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.01em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  touch-min: 44px
  gutter-compact: 8px
  gutter-default: 16px
  gutter-expanded: 24px
  pad-card: 16px
  gap-telemetry: 12px
---

## Brand & Style

This design system delivers an institutional Electronic Flight Bag (EFB) and pre-flight/in-flight dispatch environment engineered specifically for flight crews, dispatchers, and civil aviation authorities. It merges institutional authority with modern avionics instrumentation aesthetics. 

The aesthetic is functional, mission-critical, and disciplined:
- **Cockpit Ergonomics:** Low-glare, dark-adapted background surfaces with surgical contrast ratios (exceeding WCAG AAA for mission-critical flight telemetry).
- **Institutional Rigor:** Clean DGAC aeronautical navy foundation replacing legacy CRT green phosphors with contemporary flight deck glass-cockpit ergonomics.
- **Visual Clarity:** Clear distinction between operational statuses: caution/warning (aviation amber), cleared/valid (crisp emerald), active navigation/selection (aeronautical sky blue), and primary text (signal white).
- **Tone:** Professional, precise, unyielding, and calm under high-cognitive-load situations.

## Colors

The color palette is built for night and low-glare cockpit environments using high-contrast, functionally categorized hues:

- **Base Surfaces & Canvases:**
  - Deep Naval Void (`#040E1E`): Global app background, minimizing ambient light emission in cockpits.
  - Institutional Navy Base (`#071A36`): Primary surface for major views and containers.
  - Flight Deck Navy Surface (`#0A2246`): Elevated cards, toolbars, and grouped instrumentation modules.
  - Navy Border / High-Definition Division (`#0E2E5C`): Subtle, functional structural framing and separators.
  - Surface Active Navy (`#163B70`): Pressed, active, or hover surface tiers.

- **Primary Interactive & Navigation (Aeronautical Sky Blue):**
  - Base Active (`#00A3E0`): Primary callouts, active clearances, selected frequencies, primary actions.
  - Deep Sky (`#0084C7`): Interactive button hovers, segmented control backgrounds.
  - Sky Highlight (`#38BDF8`): Accent focus rings, dynamic data tags, waypoints.

- **Status & Telemetry:**
  - **Cleared / Active State:** Crisp Emerald (`#10B981`). Used strictly for "CLEARED", "VALID", "TRANSMITTED", and affirmative flight telemetry.
  - **Caution / Advisory:** Cockpit Amber (`#F59E0B`). Used for NOTAM advisories, weather cautions, weight/balance revisions, and pending ATC actions.
  - **Critical / Inoperative:** Signal Red (`#EF4444`). Reserved for hard warnings, runway incursions, or rejected clearances.

- **Typography & Signal Whites:**
  - Signal White (`#FFFFFF`): Primary telemetry readouts, selected waypoints, active altimeter/QNH, primary leg data.
  - Readout Muted (`#94A3B8`): Field labels, units (kts, ft, FL), secondary metadata.
  - Readout Inactive (`#475569`): Disabled options, unselected runway configurations.

## Typography

The typography uses Inter across all application surfaces to provide maximum legibility under rapid glance conditions, vibration, and low lighting.

- **Tabular & Monospaced Numerics:** Numeric values (altitudes, squawk codes, wind vectors, runway designators, frequencies) must strictly use OpenType tabular numerals (`font-feature-settings: "tnum" 1`) to eliminate character jitter during live updates.
- **Flight Data Labels (`label-caps`):** Used for field descriptors (e.g., `FLIGHT NO`, `RWY`, `SQUAWK`, `TRANS ALT`, `METAR`). Rendered in uppercase with generous letter spacing to avoid legibility degradation in peripheral vision.
- **Telemetry Readouts:** High-weight, high-contrast outputs designed for values requiring split-second verification by pilot or co-pilot.

## Layout & Spacing

Designed primarily for tablet/EFB hardware (portrait and landscape) as well as ruggedized mobile interfaces:

- **Grid System:**
  - **Cockpit / Tablet Landscape:** 12-column fluid grid, 24px margins, 16px gutters. Allows 2-up and 3-up operational splits (e.g., Clearance Delivery on left, Nav Log center, Approach Plates / Charts right).
  - **EFB Portrait:** 8-column layout, 16px margins, 12px gutters.
  - **Phone / Handheld Dispatch:** 4-column layout, 16px margins, 8px gutters.

- **Cockpit Touch Target Compliance:**
  - All actionable triggers (toggles, clearance confirmations, push-to-read actions) enforce a minimum touch area of `44px x 44px` (`spacing.touch-min`) to maintain reliability during turbulence.
  - Dense flight-plan line items utilize a strict 48px baseline height to eliminate mis-taps.

## Elevation & Depth

Cockpit avionics avoid dramatic, diffused drop shadows which introduce visual haze and decrease perceived screen contrast in dark conditions. Elevation is expressed via strict **tonal layering** and **low-contrast precision borders**:

- **Layer 0 (Base Canvas):** `#040E1E` — Structural viewport background.
- **Layer 1 (Card & Module Backgrounds):** `#071A36` with a hairline 1px border of `#0E2E5C`.
- **Layer 2 (Elevated Sheets, Modals, Drawer Panels):** `#0A2246` with 1px border of `#163B70`.
- **Layer 3 (Floating HUD / Critical Warnings):** `#0E2E5C` surface with a crisp 1.5px border colored according to alert level (e.g., `#00A3E0` for active selection, `#10B981` for clearance confirmation, `#F59E0B` for caution).
- **Shadows:** Kept near-zero. Modals and popovers employ only an ambient occlusion rim: `0 8px 24px -4px rgba(0, 0, 0, 0.65)`.

## Shapes

The design uses tight, technical rounded corners reflecting contemporary avionics units:
- Base corner radius is `0.375rem` (6px, consistent with `rounded-md`), preventing rounded visual waste while avoiding the severe industrial harshness of sharp zero-radius edges.
- Badges, status pills, and tactical flags maintain identical `0.375rem` boundaries or strict segmented pill forms where appropriate for continuous data meters.
- Inputs, segmented switches, and action buttons consistently match this `rounded-md` silhouette for a cohesive, ruggedized feel.

## Components

### Action & Clearance Buttons
- **Primary / Clearance Confirm:** Background `#00A3E0`, text `#040E1E` (deep navy for maximum contrast), bold weight. On tap/active: `#0084C7`.
- **State Affirmative (Cleared / Active):** Background `#10B981`, text `#040E1E`, font-weight 700.
- **Secondary Action:** Background `#0A2246`, border 1px solid `#0E2E5C`, text `#FFFFFF`. Hover/Active: border `#00A3E0`.
- **Caution / Acknowledge:** Background `#F59E0B`, text `#040E1E`.

### Telemetry Cards & Field Displays
- Base background `#071A36`, border 1px solid `#0E2E5C`, inner padding 16px.
- Section header displays `label-caps` in `#94A3B8`. Primary readout appears in `telemetry-lg` or `telemetry-md` in `#FFFFFF`.
- Units (`FT`, `KT`, `HPA`, `Z`) are docked immediately adjacent in `label-regular` `#94A3B8`.

### Status Badges & Chips
- **Clearance Granted:** Solid or subtle fill (`rgba(16, 185, 129, 0.15)`) with 1px border `#10B981`, text `#10B981`, icon checkmark.
- **Caution / Hold:** Fill `rgba(245, 158, 11, 0.15)`, border `#F59E0B`, text `#F59E0B`.
- **Active Route / Leg:** Fill `rgba(0, 163, 224, 0.15)`, border `#00A3E0`, text `#38BDF8`.

### Data Lists (Flight Strip & Waypoint Rows)
- Alternating subtle background or simple separator `#0E2E5C`.
- Minimum row height 48px.
- Waypoint IDs (e.g., `TOBOS`, `SCEL`, `VAPRO`) rendered in bold monospaced uppercase with tabular numbers for estimates and clearances.

### Input Fields & Selectors
- Background `#040E1E`, border 1px solid `#0E2E5C`, text `#FFFFFF`.
- Focused state: border 1.5px solid `#00A3E0` with a subtle `#00A3E0` 2px outer glow (`box-shadow: 0 0 0 2px rgba(0, 163, 224, 0.25)`).
- Error state: border 1.5px solid `#EF4444`.

### Avionics Switch / Segmented Controls
- Background `#040E1E`, container border 1px solid `#0E2E5C`.
- Active segment: `#0A2246` with 1px solid `#00A3E0`, text `#FFFFFF` (or crisp status green `#10B981` when selecting cleared states).