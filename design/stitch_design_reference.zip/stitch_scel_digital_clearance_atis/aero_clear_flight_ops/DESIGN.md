---
name: Aero Clear Flight Ops
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#43474f'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#747780'
  outline-variant: '#c3c6d0'
  surface-tint: '#405f8f'
  primary: '#001d3f'
  on-primary: '#ffffff'
  primary-container: '#0b3260'
  on-primary-container: '#7c9bd0'
  inverse-primary: '#a9c8fe'
  secondary: '#0061a5'
  on-secondary: '#ffffff'
  secondary-container: '#57aafe'
  on-secondary-container: '#003d6b'
  tertiary: '#311600'
  on-tertiary: '#ffffff'
  tertiary-container: '#502800'
  on-tertiary-container: '#e68117'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d6e3ff'
  primary-fixed-dim: '#a9c8fe'
  on-primary-fixed: '#001b3c'
  on-primary-fixed-variant: '#264776'
  secondary-fixed: '#d2e4ff'
  secondary-fixed-dim: '#9fcaff'
  on-secondary-fixed: '#001d36'
  on-secondary-fixed-variant: '#00497e'
  tertiary-fixed: '#ffdcc3'
  tertiary-fixed-dim: '#ffb77d'
  on-tertiary-fixed: '#2f1500'
  on-tertiary-fixed-variant: '#6e3900'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display-lg:
    fontFamily: Public Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Public Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Public Sans
    fontSize: 22px
    fontWeight: '700'
    lineHeight: 28px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Public Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  headline-sm:
    fontFamily: Public Sans
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
  body-lg:
    fontFamily: Public Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Public Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Public Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  code-flight:
    fontFamily: JetBrains Mono
    fontSize: 15px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.04em
  label-md:
    fontFamily: Public Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Public Sans
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.05em
  telemetry-data:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.02em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.125rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-base: 1rem
  space-lg: 1.25rem
  space-xl: 1.5rem
  space-2xl: 2rem
  space-3xl: 3rem
  gutter-mobile: 1rem
  margin-mobile: 1rem
  gutter-tablet: 1.25rem
  margin-tablet: 1.5rem
---

## Brand & Style

This design system delivers an authoritative, high-clarity flight operations aesthetic tailored for pilots, dispatchers, and air traffic coordinators interfacing with DGAC Chile (Dirección General de Aeronáutica Civil) services at Arturo Merino Benítez International Airport (SCEL). 

The emotional tone balances absolute institutional dependability, precision engineering, and calm operational focus under high cognitive load. Drawing from **Corporate / Modern** principles infused with safety-critical aeronautical ergonomics, the design prioritizes instant data legibility, unambiguous hierarchy, and strict regulatory confidence.

Key characteristics:
- **Pristine surfaces:** Layered cool slate and bright daylight neutrals evoke calm atmospheric clarity.
- **Authoritative structure:** Deep Chilean maritime/aviation navies establish gravitas and structural anchoring.
- **Standardized operational accents:** Sky cyan signals active vectors and telemetry; amber indicates caution or urgent NOTAM notices; emerald denotes confirmed ATC clearances and validated readbacks.
- **Zero ambiguity:** Dense tabular metrics and flight telemetry remain scannable without visual fatigue or extraneous ornamental decoration.

## Colors

The color palette is engineered for rapid situational awareness under varied cockpit and field lighting conditions, exceeding WCAG 2.1 AAA contrast ratios across all critical operational indicators.

### Palette Architecture
- **Primary Navy (`#0b3260`):** Represents institutional authority. Used for top app bars, primary action buttons, section headings, and active primary status states. An ultra-deep navy (`#0a2540`) serves as the primary text token for supreme contrast.
- **Aviation Sky Blue (`#0077c8`):** Operates as the secondary accent. Denotes active frequencies, interactive navigational links, active runway tabs, and live transponder updates.
- **Operational Amber (`#d97706`):** Dedicated tertiary color for operational advisories, active NOTAMs, weather holds, and caution states.
- **Clearance Emerald (`#059669`):** Reserved semantic color for confirmed ATC clearances, squawk validations, approved pushback/taxi readbacks, and operational green lights.
- **Surfaces & Grounds:** Base canvas uses `#f4f7fb` (a cool aeronautical slate-tinted white) to minimize eye strain. Elevated cards and modular sheets use `#ffffff`. Subtle dividers leverage `#e2e8f0` with border lines tinted with low-opacity navy (`rgba(11, 50, 96, 0.08)`).

## Typography

Typography prioritizes high legibility under motion and severe glare. 

**Public Sans** delivers an uncompromising, civic, and institutional voice for all standard UI labels, titles, and descriptive operational text. Its geometric neutrality provides clean structure without stylistic distractions.

**JetBrains Mono** is utilized strictly for alphanumeric flight operational elements:
- ICAO/IATA callsigns (`CC-COP`, `LAN501`)
- Runway designators (`RWY 17L/35R`)
- Transponder/Squawk codes (`A7100`)
- METAR, TAF, QNH, and ATIS blocks (`QNH 1014`, `WIND 190/08KT`)

Flight identifiers and timestamps must always be rendered in JetBrains Mono with tabular figures enabled to prevent horizontal shifting during live data refreshes.

## Layout & Spacing

The layout model is governed by an 8-point base grid (augmented by a 4-point micro-grid for compact data fields and pill tags).

### Layout Geometry
- **Mobile Handheld (up to 599px):** 4-column fluid layout with `16px` outer margins and `12px` gutters. Target touch fields maintain a minimum tap target of `48px x 48px` to facilitate reliable cockpit input during turbulence.
- **Tablet / EFB (Electronic Flight Bag) (600px - 1023px):** 8-column layout with `24px` margins and `16px` gutters. Incorporates a master-detail split view: left column (35% width) holds inbound/outbound queue lists, while the right pane (65% width) renders the active flight plan, ATIS details, or runway clearance strip.
- **Vertical Rhythm:** Operational data blocks must maintain consistent compact padding (`12px` vertical on list cells, `16px` on full cards) to maximize above-the-fold information density without visual crowding.

## Elevation & Depth

This design system avoids heavy, murky drop shadows in favor of a crisp architectural hierarchy composed of low-contrast borders combined with subtle, slate-tinted ambient occlusion.

### Elevation Hierarchy
1. **Ground Canvas (Level 0):** `#f4f7fb` solid tint. Passive viewport surface.
2. **Surface Cards & Data Blocks (Level 1):** Solid `#ffffff` with a crisp `1px` structural outline in `rgba(11, 50, 96, 0.09)` and a diffused light shadow: `0 1px 3px rgba(10, 37, 64, 0.04), 0 4px 12px rgba(10, 37, 64, 0.03)`.
3. **Sticky Bars & ATC Header Rails (Level 2):** Sticky flight strip headers and persistent sub-navs rest on `#ffffff` with `0 2px 8px rgba(10, 37, 64, 0.06)` and a bottom border of `1px solid #e2e8f0`.
4. **Active Operational Modals & Overlays (Level 3):** Readback confirmation drawers and critical caution dialogs feature an ambient elevation of `0 12px 32px rgba(10, 37, 64, 0.12)`, framed by a `1px` border in `#cbd5e1`.

## Shapes

The design system implements a **Soft (Level 1)** geometric standard. This subdued curvature delivers a modern yet strictly technical and disciplined appearance appropriate for civil aviation authorities.

### Geometry Specifications
- **Base Components (Text inputs, standard buttons, flight cells):** `0.25rem` (`4px`) or `0.375rem` (`6px`) corner radius.
- **Cards & Modal Containers:** `0.5rem` (`8px`) corner radius (`rounded-lg`).
- **Pills, Status Badges, Squawk Tokens:** Fully rounded (`9999px`) or `0.25rem` (`4px`) with uppercase condensed labels for immediate classification.

## Components

### Buttons & Action Controls
- **Primary Operational Action (e.g., "Confirm Readback", "Acknowledge NOTAM"):** Deep Navy (`#0b3260`) solid fill with white text (`#ffffff`), `6px` radius, bold label. Hover/Pressed state transitions to `#0a2540`.
- **Secondary Action (e.g., "Request Alternate", "Refresh ATIS"):** High-contrast Sky Blue outline (`1.5px solid #0077c8`) on pure white canvas with `#0077c8` text.
- **Clearance Confirmation Button:** Solid `#059669` fill with white text, providing distinct chromatic reassurance of definitive safe states.

### Status Chips & Flight Badges
- **Clearance Confirmed:** Background `#ecfdf5`, border `1px solid #a7f3d0`, text `#065f46`, icon checkmark.
- **Caution / NOTAM Pending:** Background `#fffbeb`, border `1px solid #fde68a`, text `#92400e`, warning triangle.
- **Active Sky / In-Flight:** Background `#f0f9ff`, border `1px solid #bae6fd`, text `#0369a1`.
- **Typography in Chips:** Always rendered in `label-sm` with tabular JetBrains Mono numerals when presenting codes, levels, or runway headings.

### Flight Strip Cards (Aero Clear Specialty Component)
- Distinct modular cards formatted after digital air traffic control strips.
- Top row: Callsign, aircraft model, and wake category in `code-flight`.
- Center row: Assigned SID/STAR, cleared altitude (`FL240`), and transponder squawk in prominent monospaced tokens.
- Right rail: Clear visual indicator stripe (4px solid accent bar on left edge) keyed to flight phase: Cyan for taxi/pushback, Amber for hold, Emerald for cleared takeoff.

### Input Fields & Selectors
- Background `#ffffff`, border `1px solid #cbd5e1`.
- Focused state: `1.5px solid #0077c8` with an ambient glow ring of `rgba(0, 119, 200, 0.15)`.
- Labels placed strictly above inputs in `label-md` with navy `#0a2540` weighting.

### Lists & Telemetry Tables
- Striped alternating row backgrounds are avoided; instead, utilize fine `1px solid #f1f5f9` dividers.
- Dense tabular layout with numeric data right-aligned in `JetBrains Mono` and metadata left-aligned in `Public Sans`.